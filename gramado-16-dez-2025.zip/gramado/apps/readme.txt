
 The folders in apps/:

-----------------------------
api/
 + The libraries for client-side GUI applications.

-----------------------------
assets/
 + Some resources.

-----------------------------
bin/
 + Final destination for compiled programs.

-----------------------------
ss/

-----------------------------
sysapps/

-----------------------------
sysshell/

-----------------------------
taskbar/

-----------------------------
your/
 + Documentations and tools.





 
 

