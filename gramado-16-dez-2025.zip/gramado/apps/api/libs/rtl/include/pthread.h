
// pthread.h

#ifndef __PTHREAD_H
#define __PTHREAD_H    1

/*
#define PTHREAD_MUTEX_DEFAULT	0
#define PTHREAD_MUTEX_NORMAL	0
#define PTHREAD_SCOPE_SYSTEM	0
#define PTHREAD_MUTEX_RECURSIVE	1
#define PTHREAD_SCOPE_PROCESS	1
#define PTHREAD_MUTEX_ERRORCHECK	2
#define PTHREAD_RWLOCK_DEFAULT_NP	2
*/

typedef int  pthread_t;

//typedef int  __pthread_barrier_t;
//typedef int  __pthread_barrierattr_t;
//typedef __SIZE_TYPE__ __pthread_key_t;
//typedef size_t  __pthread_key_t;

/*
typedef void* pthread_key_t;
typedef void* pthread_once_t;
typedef uint32_t pthread_mutex_t;
typedef void* pthread_attr_t;
typedef void* pthread_mutexattr_t;
typedef void* pthread_cond_t;
typedef void* pthread_rwlock_t;
typedef void* pthread_rwlockatrr_t;
typedef void* pthread_spinlock_t;
typedef void* pthread_condattr_t;
*/

#endif    

