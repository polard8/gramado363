
// libio.c
// rotinas de baixo nível para suportarem stdio.c
// devem começar com '__'
// see: libio/file.h

int dummmyxxxx;

