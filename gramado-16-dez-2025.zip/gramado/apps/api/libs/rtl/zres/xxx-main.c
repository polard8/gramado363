






#include <stdio.h>


// libc for linux
int main (int c, char *argv[])
{

    //_fputc_nolock('X',stdout);
    //_fputc_nolock('\n',stdout);
    return 0;
}

