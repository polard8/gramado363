
// #todo
// main file for the shared library version of the libc.


void somain (void)
{
    //todo
}



