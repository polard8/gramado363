# libgr3d - 3D library for Gramado OS.

```
 We are creating a 3D library for the client-side GUI applications for Gramado OS.
 Our starting point is getting the routines already implemented into 
 the 3D demos for Gramado OS.
```
