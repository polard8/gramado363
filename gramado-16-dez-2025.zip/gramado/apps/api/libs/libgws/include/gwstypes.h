
// gwstypes.h
// #todo: Not include in gws.h yet.

#ifndef __GWSTYPES_H
#define __GWSTYPES_H    1

#define True 1
#define False 0

//#define Status int
//#define Bool int

#endif   


