# taskbar - Taskbar application

The desktop, the taskbar, the filemanager. (The explorer, the launcher)

