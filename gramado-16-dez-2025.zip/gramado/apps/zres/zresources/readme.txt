
    How the gws environment works?

    gwssrv  - Initializes the gwssrv only. #bugbug
    gws     - Send commands to the gwssrv.
    gwsinit - Initializes the gwssrv and initializes a teminal with no wm.
    gws???
    
    
    
    
    
