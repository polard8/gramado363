

	Small client applications used for testing the server.
