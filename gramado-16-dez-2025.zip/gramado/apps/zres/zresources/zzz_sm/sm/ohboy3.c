// This is a simple init process.
// The goal here is say hello boy!

int main(void)
{
	printf("ohboy.bin: Hello world!\n");
	while(1){}
	return 0; //not reached.
}

