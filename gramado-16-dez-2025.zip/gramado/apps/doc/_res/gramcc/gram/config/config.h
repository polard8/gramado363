

//config.h

 // #todo
 //provavelmente configurar como deve reagis de acordo com a 
 //plataforma host
 
 
//#define HOST 1 //Windows 
//#define HOST 2 //Linux
//#define HOST 3 //Gramado


//se o compilador estiver compilando a si mesmo.
//nesse caso poderemos usar a flag para selecionar trechos de código 
//mais fáceis.
//#define bootstrap 1 


