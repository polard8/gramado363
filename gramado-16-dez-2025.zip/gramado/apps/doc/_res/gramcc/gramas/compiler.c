

//compiler.h 

// aqui ficará o compilador, que transformará a linguagem intermediária 
// em assembly.


// lexer >> parser >> compiler


#include "as.h"

int compile();
int compile()
{
	
	
	
	return (int) 0;
};