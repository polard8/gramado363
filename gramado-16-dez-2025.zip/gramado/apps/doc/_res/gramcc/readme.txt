
   gramcc - Gramado Compiler Collection.


   Colocaremos na pasta /gramcc todos os compiladores montadores e assemblers 
que tivermos.


//=======================================
/gramc  Compilador de c.

